              <?php
                 $cssPath=$this->get_css_path();
              ?>
            	<div class="right_tab_con zd">
              <table width="100%" border="0">
  <tr>
    <td width="29%" align="right"><strong>未置顶的页面，马上置顶：</strong></td>
    <td width="71%">&nbsp;</td>
    </tr>
  <tr>
    <td align="right">选择置顶时长：</td>
    <td><label>
      <input type="radio" name="radio" id="radio" value="radio" />
    10小时
    <input type="radio" name="radio" id="radio2" value="radio2" />
    16小时
    <input type="radio" name="radio" id="radio3" value="radio3" />
    3天
    <input type="radio" name="radio" id="radio4" value="radio4" />
    15天
    <input type="radio" name="radio" id="radio5" value="radio5" />
    30天</label></td>
    </tr>
  <tr>
    <td colspan="2"><div class="zd_mess">此次置顶需要花费您<span class="zf_m">22.4</span>元， 您的可用余额为<span class="zf_m">0.0</span>元。 余额不足</div></td>
    </tr>
  <tr>
    <td align="right"><input type="checkbox" name="checkbox" id="checkbox" />
      同意<a href="http://about.58.com/56.html?categid=1#h" target="_blank">置顶规则</a> </td>
    <td><a href="#" target="_blank"  class="zd_bt">马上充值22.4元，完成置顶</a></td>
    </tr>
</table>
              </div>
            	
            